## Welcome to GitHub Pages

You can use the [editor on GitHub](https://github.com/DanShahinConsulting/Foley/edit/main/docs/index.md) to maintain and preview the content for your website in Markdown files.

Whenever you commit to this repository, GitHub Pages will run [Jekyll](https://jekyllrb.com/) to rebuild the pages in your site, from the content in your Markdown files.

### Installation

```markdown

- `yarn install`
- `npm start`
```

