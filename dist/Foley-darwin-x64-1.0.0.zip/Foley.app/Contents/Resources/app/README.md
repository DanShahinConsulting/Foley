# Foley
sound fx board  built on electron

https://danshahinconsulting.github.io/Foley/

- supports .mp3 .wav and .ogg
- stores sounds in localstorage
- keyboard shortcuts
- midi controller support
